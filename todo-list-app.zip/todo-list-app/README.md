# To-Do List App

A simple To-Do List application built with HTML, CSS, and JavaScript.

## Features
- Add new tasks.
- Delete tasks.

## How to Use
1. Clone the repository.
2. Open `index.html` in your browser.
3. Add tasks using the input field and button.

## Technologies Used
- HTML
- CSS
- JavaScript